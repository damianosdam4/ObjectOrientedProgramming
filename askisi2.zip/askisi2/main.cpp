#include "bank_cashier.hpp"

int main(int argc, char *argv[])
{
    /* define arguments */
    int K; // parameter
    int M; // amount of reps
    int N; // amount of customers
    int L; // how many customers a cashier can handle

    int customers_served = 0;     // count the customers who has are being served
    int customers_not_served = 0; // count the customers who hasn't been served

    if (argc != 5)
    {
        cout << "Wrong amount of arguments!\n";
        return 1;
    }

    // convert arguments to integers
    K = atoi(argv[1]);
    M = atoi(argv[2]);
    N = atoi(argv[3]);
    L = atoi(argv[4]);

    Bank *bank = new Bank(L); // create a bank

    for (int i = 0; i < M; i++)
    {
        for (int j = 0; j < N; j++)
        {
            if (bank->enter(K))
                customers_served++;
            else
                customers_not_served++;
        }
        for (int w = 0; w < customers_served; w++)
        {

            bank->serve(K);
        }
        cout << "----------------------------------------" << endl;
    }

    for (int q = 0; q < customers_not_served; q++)
    {
        bank->serve(K);
    }
    bank->waiting_customers();

    delete bank; // memory deallocation

    return 0;
}
