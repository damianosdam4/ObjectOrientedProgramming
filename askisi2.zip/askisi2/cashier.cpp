#include "bank_cashier.hpp"

Cashier::Cashier(int L) : max{L}
{
    open_flag = false;
    serving_flag = false;
    customers_served = 0;
    cout << "Cashier created!" << endl;
}

Cashier::~Cashier()
{
    cout << "Cashier destroyed!" << endl;
}

void Cashier::open()
{
    customers_served = 0;
    open_flag = true;
    cout << "Cashier opened!" << endl;
}

void Cashier::close()
{
    open_flag = false;
    cout << "Cashier closed!" << endl;
}

void Cashier::serve()
{
    serving_flag = true;
}

void Cashier::free()
{
    serving_flag = false;
    customers_served++;
    cout << "Customer served!" << endl;

    if (customers_served == max)
    {
        cout << "Cashier has overworked!" << endl;
        close();
    }
}

bool Cashier::is_open()
{
    return open_flag;
}

bool Cashier::is_free()
{
    return serving_flag;
}
