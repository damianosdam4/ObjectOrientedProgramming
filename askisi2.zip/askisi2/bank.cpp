#include "bank_cashier.hpp"

Bank::Bank(int L) : cashiers{L, L, L, L, L}
{
    last_customer = 1;
    curr_serving = 1;
    cashiers[0].open();
    cout << "Bank created!" << endl
         << endl;
}

Bank::~Bank()
{
    cout << endl;
    cout << "Bank destroyed!" << endl;
}

bool Bank::enter(int K)
{
    if (check_to_open(K) == false) // if there are available cashiers
    {
        last_customer++;
        return true;
    }
    else
    {
        int current = open_cashiers();
        for (int i = 0; i < 5; i++) // for every cashier
        {

            if (cashiers[i].is_open() == false)
            {
                cashiers[i].open();
                last_customer++;
                return true;
            }
            if (current == 5) // all cashiers are serving customers
            {
                cout << "Sorry you cannot enter until some customers are served!" << endl;
                return false;
            }
        }
        return false;
    }
}

int Bank::open_cashiers()
{
    int counter_open = 0; // count the opened cashiers

    for (int i = 0; i < 5; i++)
    {
        if (cashiers[i].is_open())
            counter_open++;
    }

    cout << "Cashiers which are opened: " << counter_open << endl;

    return counter_open;
}

int last_cashier = -1; // for cyclic pick of cashiers
void Bank::serve(int K)
{
    bool closed_flag = false;

    if (open_cashiers() == 0) // if there is open cashier
        closed_flag = true;

    if (closed_flag == true)
    {
        open(0);
        cashiers[0].serve(); // the first cashier is open from the constructor
        cout << "Customer no: " << curr_serving << " by cashier no: " << 0 << endl;

        last_cashier = 0;
        cashiers[0].free();
        curr_serving++;
        exit(K);
    }
    else if (open_cashiers() == 1)
    {
        for (int i = 0; i < 5; i++)
        {
            if (cashiers[i].is_open())
            {
                cashiers[i].open();
                cashiers[i].serve();
                cout << "Customer no: " << curr_serving << " by cashier no: " << i << endl;

                last_cashier = i;
                cashiers[i].free();
                curr_serving++;
                exit(K);
            }
        }
    }
    else
    {
        int first; // Show the first cashiers which is open
        for (int i = 0; i < 5; i++)
            if (cashiers[i].is_open())
            {
                first = i;
                break;
            }
        for (int i = 0; i < 5; i++)
        {
            int current_last;
            for (int j = 0; j < 5; j++)
            {
                if (cashiers[j].is_open())
                {
                    current_last = j;
                }
            }

            if (last_cashier == current_last && cashiers[i].is_open() && cashiers[i].is_free() == false) // if the current cashier is the last one
            {
                cashiers[first].serve();
                cout << "-Customer no: " << curr_serving << " by cashier no: " << first << endl;
                last_cashier = first;
                cashiers[first].free();
                curr_serving++;
                exit(K);
            }
            else if (i != last_cashier && cashiers[i].is_open() && cashiers[i].is_free() == false) // if the current cashier isn't the last one ,and at the same time is free and open
            {
                cashiers[i].serve();
                cout << "-Customer no: " << curr_serving << " by cashier no: " << i << endl;
                last_cashier = i;
                cashiers[i].free();
                curr_serving++;
                exit(K);
            }
        }
    }
}

void Bank::exit(int K)
{
    last_customer++;
    if (check_to_close(K))
    {
        for (int i = 0; i < 5; i++)
        {
            if (cashiers[i].is_open())
            {
                close(i);
                break;
            }
        }
    }
}

bool Bank::check_to_open(int K) // cashier adequacy check
{
    int counter_closed = 0; // count the closed cashiers

    for (int i = 0; i < 5; i++)
    {
        if (cashiers[i].is_open() == false)
            counter_closed++;
    }

    if ((last_customer - curr_serving) <= counter_closed * K)
        return true;
    else
        return false;
}

bool Bank::check_to_close(int K) // cashier check surplus
{
    int counter_open = 0; // count the open cashiers

    for (int i = 0; i < 5; i++)
    {
        if (cashiers[i].is_open())
            counter_open++;
    }

    if ((last_customer - curr_serving) <= (counter_open - 1) * K)
        return true;
    else
        return false;
}

int Bank::waiting_customers()
{
    int num_waiting = last_customer - curr_serving;
    cout << "Customers who are waiting: " << num_waiting << endl;
    return num_waiting;
}

void Bank::close(int num_cashier)
{
    cashiers[num_cashier].close();
    cout << "Cashier[" << num_cashier + 1 << "] is closed!" << endl;
}

void Bank::open(int num_cashier)
{
    cashiers[num_cashier].open();
    cout << "Cashier[" << num_cashier + 1 << "] is opened!" << endl;
}
