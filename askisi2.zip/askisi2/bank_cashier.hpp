#include <iostream>

using namespace std;

class Cashier
{
private:
    int max; // maximum amount of customers that a cashier can handle
    bool open_flag;
    bool serving_flag;
    int customers_served;

public:
    Cashier(int);
    ~Cashier();
    void open();
    void close();
    void serve();
    void free();
    bool is_open();
    bool is_free();
};

class Bank
{
private:
    int last_customer;
    int curr_serving;
    Cashier cashiers[5];

public:
    Bank(int);
    ~Bank();
    bool enter(int);
    int open_cashiers();
    void serve(int);
    void exit(int);
    bool check_to_open(int);
    bool check_to_close(int);
    int waiting_customers();
    void close(int);
    void open(int);
};
