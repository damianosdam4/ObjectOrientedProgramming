#include <iostream>
#include <cstdlib>
#include <cstring>
#include <time.h>
#include <bits/stdc++.h>
#include <string.h>

using namespace std;
const int MAX = 26; // max integer of characters (check in file other.cpp / string randStr)

/* ---- FUNCTION PROTOTYPES ----- */
string randStr();
int randNum();
int randPlace();
int randPlaceCab();

/*----------- LIBRARY BASE ---------- */
class LibraryBase
{
public:
    LibraryBase()
    {
        cout << "Library base created" << endl;
    }
    ~LibraryBase()
    {
        cout << "Library base destroyed" << endl;
    }
};

/*----------- BOOK ---------- */
class Book
{
private:
    string title;
    string author;
    int isbn;

public:
    Book(const string tit, const string aut, const int isbnNum)
        : title(tit), author(aut), isbn(isbnNum) // initialiazer list
    {
        cout << "Book created" << endl;
    }
    ~Book()
    {
        cout << "Book destroyed" << endl;
    }

    void print()
    {
        cout << "Title: " << title << " | Author: " << author << " | ISBN: " << isbn << endl;
    }
};

/*----------- BOOK CASE SHELF---------- */
class Bookcase
{
private:
    int counterCase;
    Book **books;

public:
    Bookcase(int nMax)
    {
        counterCase = 0;
        books = new Book *[nMax];
        for (int i = 0; i < nMax; i++)
        {
            books[i] = nullptr;
        }
        cout << "Bookcase shelf created" << endl;
    }
    ~Bookcase()
    {
        cout << "Bookcase shelf destroyed" << endl;
        delete[] books; // deallocation
    }
    bool place_book(Book *book, int nMax)
    {
        if (nMax == counterCase) // if the shelf is full
        {
            return false;
        }
        else
        {
            books[counterCase] = book; // place a book in array of books
            counterCase++;
            return true;
        }
    }
    bool take_book(int nMax)
    {
        if (counterCase == 0) // shelf if empty
        {
            return false;
        }
        else
        {
            for (int i = 0; i < nMax; i++)
            {
                if (books[i] != nullptr) // if there is a book
                {
                    books[i] == nullptr; // remove the book
                    counterCase--;
                    return true;
                }
            }
        }
    }
    void print()
    {
        for (int i = 0; i < counterCase; i++)
        {
            books[i]->print();
        }
        if (counterCase == 0)
            cout << "Empty shelf" << endl;
    }
};

/*----------- CABINET ---------- */
class Cabinet
{
private:
    Bookcase upCaseOfCab, downCaseOfCab; // create the two bookcases of cabinet

public:
    Cabinet(int nMax) : upCaseOfCab(nMax), downCaseOfCab(nMax) // initiazer list
    {
        cout << "Cabinet created" << endl;
    }
    ~Cabinet()
    {
        cout << "Cabinet destroyed" << endl;
    }
    bool place_book(int placer, Book *book, int nMax)
    {
        if (placer == 1)
        {
            if (upCaseOfCab.place_book(book, nMax) == true)
            {
                cout << "Placing book in up bookcase shelf of cabinet" << endl;
                return true;
            }
            else
                return false;
        }
        else if (placer == 2)
        {
            if (downCaseOfCab.place_book(book, nMax) == true)
            {
                cout << "Placing book in down bookcase shelf of cabinet" << endl;
                return true;
            }
            else
                return false;
        }
    }
    bool take_book(int placer, int nMax)
    {
        if (placer == 1)
        {
            if (upCaseOfCab.take_book(nMax) == true)
            {
                cout << "Taking book from up bookcase shelf of cabinet" << endl;
                return true;
            }
            else
                return false;
        }
        else if (placer == 2)
        {
            if (downCaseOfCab.take_book(nMax) == true)
            {
                cout << "Taking book from down bookcase shelf of cabinet" << endl;
                return true;
            }
            else
                return false;
        }
    }
    void printUp()
    {
        upCaseOfCab.print();
    }
    void printDown()
    {
        downCaseOfCab.print();
    }
};

/*----------- LIBRARY ---------- */
class Library
{
private:
    int counterLib;
    LibraryBase base;
    Cabinet cab;
    Bookcase upCase, downCase, middleCase;

public:
    Library(int nMax) : cab(nMax), upCase(nMax), downCase(nMax), middleCase(nMax) // inializer list
    {
        counterLib = 0;
        cout << "Library created" << endl;
    }
    ~Library()
    {
        cout << "Library destroyed" << endl;
    }
    bool place_book(int placer, Book *book, int nMax)
    {
        switch (placer)
        {
        case 1:
            if (upCase.place_book(book, nMax) == true)
            {
                counterLib++;
                cout << "Placing book in up bookcase self" << endl;
                return true;
                break;
            }
            else
                return false;
        case 2:
            if (middleCase.place_book(book, nMax) == true)
            {
                counterLib++;
                cout << "Placing book in middle bookcase self" << endl;
                return true;
                break;
            }
            else
                return false;
        case 3:
            if (downCase.place_book(book, nMax) == true)
            {
                counterLib++;
                cout << "Placing book in down bookcase self" << endl;
                return true;
                break;
            }
            else
                return false;
        case 4:
            if (cab.place_book(randPlaceCab(), book, nMax) == true)
            {
                counterLib++;
                return true;
                break;
            }
            else
                return false;
        }
    }
    bool take_book(int placer, int nMax)
    {
        switch (placer)
        {
        case 1:
            if (upCase.take_book(nMax) == true)
            {
                counterLib--;
                cout << "Taking book from up bookcase self" << endl;
                return true;
                break;
            }
            else
                return false;
        case 2:
            if (middleCase.take_book(nMax) == true)
            {
                counterLib--;
                cout << "Taking book from middle bookcase self" << endl;
                return true;
                break;
            }
            else
                return false;
        case 3:
            if (downCase.take_book(nMax) == true)
            {
                counterLib--;
                cout << "Taking book from down bookcase self" << endl;
                return true;
                break;
            }
            else
                return false;
        case 4:
            if (cab.take_book(randPlaceCab(), nMax) == true)
            {
                counterLib--;
                return true;
                break;
            }
            else
                return false;
        }
    }
    void print()
    {
        cout << "-Up bookcase shelf: " << endl;
        upCase.print();
        cout << endl;

        cout << "-Middle bookcase shelf: " << endl;
        middleCase.print();
        cout << endl;

        cout << "-Down bookcase shelf: " << endl;
        downCase.print();
        cout << endl;

        cout << "-Up bookcase shelf of Cabinet: " << endl;
        cab.printUp();
        cout << endl;

        cout << "-Down bookcase shelf of Cabinet: " << endl;
        cab.printDown();

        cout << "-----------------------------------------" << endl;
    }
};
