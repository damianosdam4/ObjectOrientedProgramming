/* ERGASIA 1 OOP 2021-22 */
/* DAMIANAKIS DAMIANOS */
/* 1115201800306 */

#include "library.hpp"

int main(int argc, char *argv[])
{
    int nMax, L, k1, k2; // define arguments
    srand(time(NULL));

    if (argc != 5)
    {
        cout << "Wrong amount of arguments!\n";
        return 1;
    }

    // convert argumnets to integers
    nMax = atoi(argv[1]);
    L = atoi(argv[2]);
    k1 = atoi(argv[3]);
    k2 = atoi(argv[4]);

    Book **currentArray = new Book *[L]; // current array to store books

    Library Lib(nMax); // create the library

    for (int i = 0; i < L; i++) // placing each book in current array
    {
        currentArray[i] = new Book(randStr(), randStr(), randNum());
    }

    for (int i = 0; i < k1; i++) // placing k1 books to random parts of library
    {
        if (Lib.place_book(randPlace(), currentArray[i], nMax) == true)
        {
            cout << "Book has been placed successfully in the library! " << endl;
        }
        else
            cout << "Placing book in library failed!" << endl;
    }
    cout << "\n----------------Content of library after placing process----------------" << endl;
    Lib.print(); // display the library

    for (int i = 0; i < k2; i++) // taking k2 books from random parts of library
    {
        if (Lib.take_book(randPlace(), nMax) == true)
        {
            cout << "Book has been taken successfully from the library! " << endl;
        }
        else
            cout << "Taking book from library failed!" << endl;
    }
    cout << "\n\n----------------Content of library after taking process----------------" << endl;
    Lib.print(); // display the library

    // deallocation
    for (int i = 0; i < L; i++)
        delete currentArray[i];
    delete[] currentArray; // deallocation
}
