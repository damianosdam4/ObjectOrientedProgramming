#include "library.hpp"

string randStr() // return random string of 10 characters for author and title of book
{
    char alphabet[MAX] = {'a', 'b', 'c', 'd', 'e', 'f', 'g',
                          'h', 'i', 'j', 'k', 'l', 'm', 'n',
                          'o', 'p', 'q', 'r', 's', 't', 'u',
                          'v', 'w', 'x', 'y', 'z'};
    string res = "";
    for (int i = 0; i < 10; i++) // return random string with 10 characters
    {
        res = res + alphabet[rand() % MAX];
    }
    return res;
}

int randNum() // return random number from 1 to 1000 for isbn
{
    return (rand() % 1000 + 1);
}

int randPlace()
{
    return (rand() % 4 + 1);
}

int randPlaceCab()
{
    return (rand() % 2 + 1);
}